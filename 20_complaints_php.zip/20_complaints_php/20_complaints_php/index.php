<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Complaint System</title>
</head>
<body>
    <h1>Welcome to the Complaint System</h1>
    <p>
        This system allows students to register complaints, and administrators can view and manage those complaints.
    </p>
    <p>
        <a href="register.php">Student Registration</a> |
        <a href="login.php">Student Login</a> |
        <a href="admin_register.php">Admin Registration</a> |
        <a href="admin_login.php">Admin Login</a>
    </p>
</body>
</html>
