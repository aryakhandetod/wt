// App.js
import React from "react";
import CurrencyConverter from "./CurrencyConverter";
import "./App.css";

function App() {
  return (
    <div className="App">
      <CurrencyConverter />
    </div>
  );
}

export default App;
