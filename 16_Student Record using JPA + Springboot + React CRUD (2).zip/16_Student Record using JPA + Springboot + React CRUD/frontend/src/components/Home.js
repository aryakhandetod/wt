import React from 'react'
import './Home.css'
export default function Home() {
    return (
      <div className="home">
      <h1>Welcome to CRUD APP</h1>
      <br/>
      <p>Hello From CRUD</p>
  </div>
    )
  }