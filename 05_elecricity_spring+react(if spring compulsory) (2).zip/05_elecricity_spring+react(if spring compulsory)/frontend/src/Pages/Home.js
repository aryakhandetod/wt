import React from 'react'
import './Home.css'
export default function Home() {
  return (
    <div className="home">
    <h1>Welcome to MSEB</h1>
    <br/>
    <p>Go to the Bill section to pay your Bill</p>
</div>
  )
}
